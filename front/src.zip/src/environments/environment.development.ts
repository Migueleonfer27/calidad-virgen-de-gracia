export const environment = {
  apiUrl: 'http://localhost:9090/api',
};
