import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-page',
  standalone: false,
  
  templateUrl: './admin-page.component.html',
  styleUrl: './admin-page.component.css'
})
export class AdminPageComponent {

}
