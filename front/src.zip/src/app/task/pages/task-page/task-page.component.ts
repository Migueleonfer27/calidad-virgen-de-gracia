import { Component } from '@angular/core';

@Component({
  selector: 'app-task-page',
  standalone: false,
  
  templateUrl: './task-page.component.html',
  styleUrl: './task-page.component.css'
})
export class TaskPageComponent {

}
